<?php
session_start();
$link = mysqli_connect('localhost', 'cj24332_valen', '69LrD38z', 'cj24332_valen');




if(isset($_POST['go']) )
{
    //проверки

    
    $errors = array();

    //
    ///проверка логина
    //

    $result = $link->query(" SELECT * FROM `comics` WHERE login = '{$_POST["login"]}' ;");
    $user = $result->fetch_assoc();

    if(trim($_POST['login']) == '')
    {
        $errors[] = 'введите логин!';
        
        
    }

    if(mb_strlen($_POST['login']) < 3 )
    {
        $errors[] = 'не меньше 3 символов в логине ! ';
        
    }

    if($user > 0)
    {
        $errors[] = 'пользователь с таким логином уже существует !';
       
    }

    //
    ///проверка email
    //

    if(trim($_POST['email']) == '')
    {
        $errors[] = 'введите email';
        
    }

    $em = $link->query(" SELECT * FROM `users` WHERE email = '{$_POST["email"]}' ;");
    $new = $em->fetch_assoc();
    
    if($new > 0)
    {
        $errors[] = 'пользователь с такой почтой  уже существует !';
    }

    //
    ///проверка пароля 
    //

    if($_POST['password'] == '')
    {
        $errors[] = 'введите пароли!';
    }
    if($_POST['password'] != $_POST['password2'])
    {
        $errors[] = 'повторный пароль не совпадает!';
    }

    if(mb_strlen($_POST['password']) < 5 ){
        $errors[] = ' пароль должен содержать не меньше 5 символов  ';
    }

    ////
    //все хорошо

    if(empty($errors)){
        
        $login = $_POST['login'];
        $email = $_POST['email'];
        $password = $_POST['password'];

       

        $q = "INSERT INTO `users` (`id`, `login`, `Email`, `password`, `activ`) 
        VALUES (NULL, '$login', '$email', '$password', 0);";
        mysqli_query($link, $q);
        $m[] = $login;
        $m[] = $email;
        $m[] = $password;
        $_SESSION['user'] = $m;
        
        header('location: https://valen.xd0.ru/cms/index.php');

    }else{
        require("system/function.php");
        alerts('danger', $errors);
    }
        
};
require("template/header.php");


?>



<html>
<head>
    <meta charset="UTF-8">
    <title>регистрация</title>
</head>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link rel="stylesheet" href="reg.css">
<body>


<main class="flex-shrink-0">
  <div class="container">

    <h1 class="mt-5">Регистрация</h1>
    <p class="lead">Что-бы оставлять комментарии, вам необходимо пройти регистрацию</p>

    <form  method="post">
      <div class="mb-3">
        <label for="login" class="form-label">Логин</label>
        <input type="text" class="form-control" id="login" name="login">
      </div>
      <div class="mb-3">
        <label for="password1" class="form-label">Пароль 1</label>
        <input type="password" class="form-control" id="password1" name="password">
      </div>
      <div class="mb-3">
        <label for="password2" class="form-label">Пароль 2</label>
        <input type="password" class="form-control" id="password2" name="password2">
      </div>                  
      <div class="mb-3">
        <label for="email" class="form-label">Адрес почты</label>
        <input type="email" class="form-control" id="email" name="email">
      </div>
      <button type="submit" class="btn btn-primary" name="go">Зарегистрироваться</button>
    </form>

  </div>
</main>
</body>
</html>