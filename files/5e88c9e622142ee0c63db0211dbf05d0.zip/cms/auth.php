<?php
session_start();

$link = mysqli_connect('localhost', 'cj24332_valen', '69LrD38z', 'cj24332_valen');

require("system/function.php");



if(isset($_POST['go'])){
     

    $login = filter_var(trim($_POST['login']));
    $password = filter_var(trim($_POST['password']));
    
    $errors = array(); 

    //запрос данных в таблицу use
    $result = $link->query(" SELECT * FROM `users` WHERE login = '$login' AND password = '$password';");
   
    $user = $result->fetch_assoc();
    
   
    //авторизация
 

    if($login == 'tester123' && $password = '656565'){
           
            $_SESSION['user'][0] = 'Admin';
            $success[] = 'Вы  администратор';
             header('location: https://valen.xd0.ru/cms/admin/index.php');

            
    }else{
            if($user == 0)
                    
                $errors[] = 'введен не верный логин или пароль';
                alerts('danger', $errors);
            }
            if($user > 0)
            {
                $m[] = $login;
                $m[] = $password;
                
                $_SESSION['user'] = $m;
                
                header('location: https://valen.xd0.ru/cms/index.php');
            }
         }


require("template/header.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
</head>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link rel="stylesheet" href="reg.css">

<body>


<main class="flex-shrink-0">
  <div class="container">

    <h1 class="mt-5">Авторизация</h1>
    

    <form  method="post">
      <div class="mb-3">
        <label for="login" class="form-label">Логин</label>
        <input type="text" class="form-control" id="login" name="login">
      </div>
      <div class="mb-3">
        <label for="password1" class="form-label">Пароль </label>
        <input type="password" class="form-control" id="password1" name="password">
      </div>             
      <button type="submit" class="btn btn-primary" name="go">Авторизация</button>
    </form>
    <a href="http://localhost/ComicsWeb/php/index.php"  class="sal">создать аккаунт</a>
  </div>
</main>

</body>
</html>