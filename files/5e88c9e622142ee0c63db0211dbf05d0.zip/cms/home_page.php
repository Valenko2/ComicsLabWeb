<?php

    session_start();

    $link = mysqli_connect('localhost', 'cj24332_valen', '69LrD38z', 'cj24332_valen');

    $title = "Ошибка 404";
    $countent = "страница не найдена";
    $q = "SELECT * FROM `users` ";
    $at = mysqli_query($link, $q);
    $ur = mysqli_fetch_all($at, MYSQLI_ASSOC);

    require("template/header.php");
    
    

    if(empty($_GET['url']) == false){
        $q = "SELECT * FROM `home_page` WHERE url ='{$ur['login']}'";
        $at = mysqli_query($link, $q);
        $url = mysqli_fetch_all($at, MYSQLI_ASSOC);

        $name = $url[0]['login'];
        
        }
    
   
   
?>
  <!-- Begin page content -->
  <main class="flex-shrink-0">
    <div class="container">
      <p class="mt-5"><?php echo $title ?></p>
      <p class="lead">ваш личный кабинет, <?php echo $name ?></p>
    </div>
  </main>
  <!-- End page content -->
  <?php 
    require("template/footer.php");
    ?>
</body>
</html>