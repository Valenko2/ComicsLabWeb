<?php
	session_start();

    require'../system/function.php';
    require'../link.php';
    require'template/header.php';
    if(isset($_POST['go'])){
        $errors = array();
        $success = array();

         $errors = array();
        $success = array();

        if($_POST['sort'] == ''){ $errors[] = 'укадите порядок'; }
        if($_POST['parent'] == ''){ $errors[] = 'укажите родителя'; }

        if(empty($errors)){ 
            $q = 'UPDATE `menu` SET  `parent` = "'.$_POST['parent'].'", `title`= "'.$_POST['title'].'", `href`= "'.$_POST['href'].'", `sort` = '.$_POST['sort'].' WHERE `id` = '.$_GET["id"].' ';
            $res = mysqli_query($link, $q);
        }
        

        if($res){
            $success[] = 'страница изменена';
        }else{
            $errors[] = 'страница не изменена';
        }
        alerts('danger', $errors);
        alerts('success', $success);
    }
     $q = "SELECT * FROM `menu` WHERE `id` = ".$_GET['id']." ";
         $at = mysqli_query($link, $q);
         $page = mysqli_fetch_all($at, MYSQLI_ASSOC);
        
?>
    <main class="flex-shrink-0">
        <div class="container">
           
            <a  class="btn btn-success mt-3" href="menu.php">назад</a>
            <h1 class="mt-5">редактировать пункт</h1>

            <form method="post">
                <div class="mb-3">
                    <label class="form-label">Родитель</label>
                    <input type="text" name="parent" class="form-control" placeholder="введите url" value="<?php 
                     echo $page[0]['parent']; ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Атрибут href</label>
                    <input type="text" name="href" class="form-control" placeholder="введиет название" value="<?php 
                    echo $page[0]['href']; ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">текст ссылки</label>
                     <input type="text" name="href" class="form-control" placeholder="введиет название" value="<?php 
                    echo $page[0]['title']; ?>">
                </div>
               <div class="mb-3">
                    <label class="form-label">sort</label>
                     <input type="text" name="href" class="form-control" placeholder="введиет название" value="<?php 
                    echo $page[0]['sort']; ?>">     
                </div>
               <button type="submit" class="btn btn-primary" name="go">изменить</button>
            </form>
        </div>
    </main>
<?php

    require'template/footer.php';

?>