<?php
	session_start();

	require'../system/function.php';
	require'../link.php';
	require'template/header.php';

	$q = 'SELECT * FROM `menu` ORDER BY `parent`, `sort` ';
	$res = mysqli_query($link, $q);
	$data = mysqli_fetch_all($res, MYSQLI_ASSOC);

?>
	<main class="flex-shrink-0">
		<div class="container">
			<a  class="btn btn-success mt-3" href="new_menu.php ">добавить</a>

			<h1 class="mt-5">меню</h1>
			<table class="table table-striped table-dark">
				  <thead>
				    <tr>
				      <th scope="col">id</th>
				      <th scope="col">Родитель</th>
				      <th scope="col">href</th>
				      <th scope="col">Текст</th>
				      <th scope="col">Порядок</th>
				      <th scope="col">Операции</th>
				    </tr>
				  </thead>
				  <tbody>
				  <?php
				  foreach($data as $page){
					    echo'<tr>';
					 		echo'<th>'.$page["id"].'</th>';
					    	echo'<td>'.$page["parent"].'</td>';
					    	echo'<td>'.$page["href"].'</td>';
					    	echo'<td>'.$page["title"].'</td>';
					    	echo'<td>'.$page["sort"].'</td>';
					    	echo'<td>
					    			<a  class="btn btn-info" href = "edit_menu.php?id='.$page["id"].'">редактировать</a>
					    			<a  class="btn btn-danger" href = "del_menu.php?id='.$page["id"].'")>удалить</a>
					    		</td>';
					    echo'</tr>';
				   }
				  ?>
				  </tbody>
			</table>
		</div>
	</main>
<?php

	require'template/footer.php';

?>