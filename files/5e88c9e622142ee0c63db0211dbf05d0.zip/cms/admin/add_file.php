<?php
    session_start();

    require'../link.php';
     require'../system/function.php';
    require'template/header.php';
    $allowd_file = array('jpg', 'jpeg', 'gif', 'png', 'zip', 'txt', 'webp', 'sql');

    if(isset($_POST['go'])){
        $success = array();
        $errors = array();
        $tmp_name = $_FILES['unfile']['tmp_name'];
        $file_name =  $_FILES['unfile']['name'];
        $file_size = $_FILES['unfile']['size'];
        $file_ext = getFileExt($file_name);
        $file_errors = $_FILES['unfile']['error'];

        if($file_errors == 1 || $file_errors == 2){
            $errors[] = 'превышен размер файла';
        }elseif($file_errors != 0){
            $errors[] = 'Ошибка загрузки';
        }elseif(!in_array($file_ext, $allowd_file)){
            $errors[] = 'Файлы такого типа запрещены';
        }else{
            $newName = generaterFileName($file_name);
            if(move_uploaded_file($tmp_name, "../files/" . $newName)){
                 $success[] = 'Файлы был успешно добавлен';
            }
        }
        alerts('success', $success);
        alerts('danger',$errors);
    }
?>
    <main class="flex-shrink-0">
        <div class="container">
           
            <a  class="btn btn-success mt-3" href="files.php">назад</a>
            <h1 class="mt-5">Загрузить файл</h1>

            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">выберите файл (2МБ)</label>
                    <input type="file" name="unfile" class="form-control" placeholder="введите url">
                </div>
               <button type="submit" class="btn btn-primary" name="go">Загрузить</button>
            </form>
        </div>
    </main>
<?php

    require'template/footer.php';

?>