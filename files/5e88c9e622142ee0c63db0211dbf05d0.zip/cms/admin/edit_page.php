<?php
    session_start();

    require'../system/function.php';
    require'../link.php';
    require'template/header.php';
    if(isset($_POST['go'])){
        $errors = array();
        $success = array();

        if($_POST['url'] == ''){ $errors[] = 'заполните поле url'; }
        if($_POST['title'] == ''){ $errors[] = 'заполните поле title'; }
        if(mb_strlen($_POST['content']) < 30){ $errors[] = 'ваша статья слишком маленькая, должно быть не меньше 30 символов'; }
        $activ = 0;
        if(!empty($_POST['action'])){
                $activ = 1;
            }
        if(empty($errors)){ 
            $countent = mysqli_real_escape_string($link, $_POST['content']);
            $q = 'UPDATE `page` SET  `url` = "'.$_POST['url'].'", `title`= "'.$_POST['title'].'", `content`= "'.$countent.'", `activ` = '.$activ.' WHERE `id` = '.$_GET["id"].' ';
            $res = mysqli_query($link, $q);
        }
        

        if($res){
            $success[] = 'страница изменена';
        }else{
            $errors[] = 'страница не изменена';
        }
        alerts('danger', $errors);
        alerts('success', $success);
    }
     $q = "SELECT * FROM `page` WHERE `id` = ".$_GET['id']." ";
         $at = mysqli_query($link, $q);
         $page = mysqli_fetch_all($at, MYSQLI_ASSOC);
        
?>
    <main class="flex-shrink-0">
        <div class="container">
           
            <a  class="btn btn-success mt-3" href="pages.php">назад</a>
            <h1 class="mt-5">редактировать страницу</h1>

            <form method="post">
                <div class="mb-3">
                    <label class="form-label">ссылка</label>
                    <input type="text" name="url" class="form-control" placeholder="введите url" value="<?php 
                     echo $page[0]['url']; ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">название</label>
                    <input type="text" name="title" class="form-control" placeholder="введиет название" value="<?php 
                    echo $page[0]['title']; ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">содержание</label>
                    <textarea  name="content" class="form-control" rows="3"><?php 
                    echo $page[0]['content']; ?></textarea>
                </div>
                <div class="form-chek">
                    <input type="checkbox" class="from-chek" name="action" value="off" checked>
                     <label class="form-check-label">Показать на сайте</label>
                </div>
               <button type="submit" class="btn btn-primary" name="go">изменить</button>
            </form>
        </div>
    </main>
<?php

    require'template/footer.php';

?>