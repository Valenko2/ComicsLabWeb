<?php
	session_start();

	require'../system/function.php';
	require'../link.php';
	require'template/header.php';

	$q = 'SELECT * FROM `page`';
	$res = mysqli_query($link, $q);
	$data = mysqli_fetch_all($res, MYSQLI_ASSOC);

?>
	<main class="flex-shrink-0">
		<div class="container">
			<a  class="btn btn-success mt-3" href="new_page.php ">добавить</a>

			<h1 class="mt-5">страницы</h1>
			<table class="table table-striped table-dark">
				  <thead>
				    <tr>
				      <th scope="col">id</th>
				      <th scope="col">url</th>
				      <th scope="col">заголовок</th>
				      <th scope="col">отображение</th>
				       <th scope="col">операция</th>
				    </tr>
				  </thead>
				  <tbody>
				  <?php
				  foreach($data as $page){
					    echo'<tr>';
					 		echo'<th>'.$page["id"].'</th>';
					    	echo'<td>'.$page["url"].'</td>';
					    	echo'<td>'.$page["title"].'</td>';
					    	echo'<td>'.$page["activ"].'</td>';
					    	echo'<td>
					    			<a  class="btn btn-info" href = "edit_page.php?id='.$page["id"].'">редактировать</a>
					    			<a  class="btn btn-danger" href = "del_page.php?id='.$page["id"].'" onclick="return confirm(\'подтведите удаление\')">удалить</a>
					    		</td>';
					    echo'</tr>';
				   }
				  ?>
				  </tbody>
			</table>
		</div>
	</main>
<?php

	require'template/footer.php';

?>