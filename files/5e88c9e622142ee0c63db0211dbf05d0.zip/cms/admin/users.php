<?php
	session_start();

	require'../system/function.php';
	require'../link.php';
	require'template/header.php';
	$q = 'SELECT * FROM `users`';
	$res = mysqli_query($link, $q);
	$user = mysqli_fetch_all($res, MYSQLI_ASSOC);

?>
	<main class="flex-shrink-0">
		<div class="container">
			<h1 class="mt-5">Пользователи: </h1>
			<table class="table table-striped table-dark">
				  <thead>
				    <tr>
				      <th scope="col">id</th>
				      <th scope="col">login</th>
				      <th scope="col">email</th>
				      <th scope="col">дата </th>
				      <th scope="col">Бан</th>
				       <th scope="col">операция</th>
				    </tr>
				  </thead>
				  <tbody>
				  <?php
				  

				  foreach($user as $page){
				  	 	$activ = 'не забанен';
				  	 	if(empty($page['activ'])){
				  	 		$activ = 'не забанен';
				  	 	}
				  	 	if($page['activ'] == 1){
				  	 		 $activ = 'забанен';
				  	 		 $_SESSION['user'][0] = 'Ban';
				  	 	}

					    echo'<tr>';
					 		echo'<th>'.$page["id"].'</th>';
					    	echo'<td>'.$page["login"].'</td>';
					    	echo'<td>'.$page["Email"].'</td>';
					    	echo'<td>'.$page["data"].'</td>';
					    	echo'<td>'.$activ.'</td>';
					    	echo'<td>
					    			<a  class="btn btn-danger" href = "ban_user.php?id='.$page["id"].'">Забанить</a>
					    			<a  class="btn btn-success" href = "edit_user.php?id='.$page["id"].'">разбанить</a>
					    		</td>';
					    echo'</tr>';
				   }
				  ?>
				  </tbody>
			</table>
		</div>
	</main>

<?php

	require'template/footer.php';

?>