<?php
	$link = mysqli_connect('localhost', 'cj24332_valen', '69LrD38z', 'cj24332_valen');

	$q = "DELETE FROM `comments` WHERE `id` = ".$_GET['id']." ";
	$at = mysqli_query($link, $q);
	header('location: https://valen.xd0.ru/cms/index.php');

?>