<?php
    session_start();

    require'../link.php';
    require'template/header.php';
    if(isset($_POST['go'])){
        $errors = array();
        $success = array();

        if($_POST['url'] == ''){ $errors[] = 'заполните поле url'; }
        if($_POST['title'] == ''){ $errors[] = 'заполните поле title'; }
        if(mb_strlen($_POST['content']) < 30){ $errors[] = 'ваша статья слишком маленькая, должно быть не меньше 30 символов'; }
        $activ = 0;
        if(!empty($_POST['action'])){
                $activ = 1;
            }

        if(empty($errors)){ 
            $countent = mysqli_real_escape_string($link, $_POST['content']);
            $q = 'INSERT INTO `page` (`url`, `title`, `content`, `activ`) 
            VALUES ("'.$_POST['url'].'", "'.$_POST['title'].'", "'.$countent.'", '.$activ.')';
            $res = mysqli_query($link, $q);
        }else{
            
        }

        if($res){
            $success[] = 'страница добавлена';
        }else{
            $errors[] = 'страница не добавлена';
        }
         require'../system/function.php';
        alerts('danger', $errors);
        alerts('success', $success);
    }
?>
    <main class="flex-shrink-0">
        <div class="container">
           
            <a  class="btn btn-success mt-3" href="pages.php">назад</a>
            <h1 class="mt-5">добавить страницу</h1>

            <form method="post">
                <div class="mb-3">
                    <label class="form-label">ссылка</label>
                    <input type="text" name="url" class="form-control" placeholder="введите url" value="<?php 
                     echo $page['url'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">название</label>
                    <input type="text" name="title" class="form-control" placeholder="введиет название" value="<?php 
                    if(isset($_POST['title'])){ echo $_POST['title'];} ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">содержание</label>
                    <textarea  name="content" class="form-control" rows="3" ></textarea>
                </div>
                <div class="form-chek">
                    <input type="checkbox" class="from-chek" name="action" value="on" checked>
                     <label class="form-check-label">Показать на сайте</label>
                </div>
               <button type="submit" class="btn btn-primary" name="go">добавить</button>
            </form>
        </div>
    </main>
<?php

    require'template/footer.php';

?>