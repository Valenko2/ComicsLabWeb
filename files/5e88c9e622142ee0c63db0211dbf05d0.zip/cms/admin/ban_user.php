<?php
	session_start();
	$link = mysqli_connect('localhost', 'cj24332_valen', '69LrD38z', 'cj24332_valen');
	$q = "UPDATE `users` SET `activ` = 1 WHERE `id` = ".$_GET['id']." ";
	$at = mysqli_query($link, $q);
	header('location: https://valen.xd0.ru/cms/admin/users.php');

?>
