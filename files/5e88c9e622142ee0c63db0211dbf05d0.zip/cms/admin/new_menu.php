<?php
    session_start();

    
    require'../link.php';
    require'template/header.php';
    if(isset($_POST['go'])){
        $errors = array();
        $success = array();

        if($_POST['sort'] == ''){ $errors[] = 'укадите порядок'; }
        if($_POST['parent'] == ''){ $errors[] = 'укажите родителя'; }

        if(empty($errors)){ 
            $countent = mysqli_real_escape_string($link, $_POST['content']);
            $q = 'INSERT INTO `menu` (`parent`, `title`, `href`, `sort`) 
            VALUES ("'.$_POST['parent'].'", "'.$_POST['title'].'", "'.$_POST['href'].'", '.$_POST['sort'].')';
            $res = mysqli_query($link, $q);
        }else{
            
        }

        if($res){
            $success[] = 'Пункт меню добавлен';
        }else{
            $errors[] = 'Пункт меню не добавлен';
        }
        require'../system/function.php';
        alerts('danger', $errors);
        alerts('success', $success);
    }
?>
    <main class="flex-shrink-0">
        <div class="container">
           
            <a  class="btn btn-success mt-3" href="menu.php">назад</a>
            <h1 class="mt-5">добавить страницу</h1>

            <form method="post">
                <div class="mb-3">
                    <label class="form-label">Родитель</label>
                    <input type="text" name="parent" class="form-control" placeholder="введите url" >
                </div>
                <div class="mb-3">
                    <label class="form-label">Атрибут href</label>
                    <input type="text" name="href" class="form-control" placeholder="введиет название" >
                </div>
                <div class="mb-3">
                    <label class="form-label">текст ссылки</label>
                    <input type="text" name="title" class="form-control" placeholder="введиет название" >
                </div>
                 <div class="mb-3">
                    <label class="form-label">Sort</label>
                    <input type="text" name="sort" class="form-control" placeholder="укажите порядок" >
                </div>
               <button type="submit" class="btn btn-primary" name="go">добавить</button>
            </form>
        </div>
    </main>
<?php

    require'template/footer.php';

?>