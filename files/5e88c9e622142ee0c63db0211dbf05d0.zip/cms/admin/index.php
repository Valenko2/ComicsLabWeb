<?php
	session_start();

	require'../system/function.php';
	require'../link.php';
	require'template/header.php';
	$q = "SELECT * FROM `menu` ";
	$at = mysqli_query($link, $q);
    $menu = mysqli_fetch_all($at, MYSQLI_ASSOC);

    $q = 'SELECT * FROM `page`';
	$res = mysqli_query($link, $q);
	$data = mysqli_fetch_all($res, MYSQLI_ASSOC);

	$q = 'SELECT * FROM `users`';
	$res = mysqli_query($link, $q);
	$user = mysqli_fetch_all($res, MYSQLI_ASSOC);

?>
	<main class="flex-shrink-0">
		<div class="container">
			<h1 class="mt-5">Здраствуй, администратор !</h1>
			<br>
				<ul class="list-group">
  					<li class="list-group-item active">Статистика:</li>
  					<li class="list-group-item">Пользователей: <?php echo count($user) ?></li>
  					<li class="list-group-item">Страниц: <?php echo count($data) ?></li>
  					<li class="list-group-item">Пункты меню: <?php echo count($menu) ?></li>
				</ul>
			</ul>
		</div>
	</main>
<?php

	require'template/footer.php';

?>