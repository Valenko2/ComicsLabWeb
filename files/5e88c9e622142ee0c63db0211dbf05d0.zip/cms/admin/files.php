<?php
	session_start();

	require'../system/function.php';
	require'../link.php';
	require'template/header.php';

	$files = scandir('../files');
	array_shift($files);
	array_shift($files);
?>
	<main class="flex-shrink-0">
		<div class="container">
			<a  class="btn btn-success mt-3" href="add_file.php ">добавить</a>
			<h1 class="mt-5">Файлы</h1>

			<table class="table table-striped table-dark">
				  <thead>
				    <tr>
				      <th scope="col">id</th>
				      <th scope="col">Миниатюра</th>
				      <th scope="col">путь</th>
				      <th scope="col">Операция</th>
				     
				    </tr>
				  </thead>
				  <tbody>
				  <?php
				  	$i = 1;
				  	$img_ext = array('jpg', 'jpeg', 'gif', 'png', );
				  	foreach($files as $file){
				  		$preview = 'нет';
				  		$file_ext = getFileExt($file); 
				  		if(in_array($file_ext, $img_ext)){
				  			$preview = '<img width="50"  src="../files/'.$file.'">';

				  		}
				  		echo '<tr>';
				  		echo '<td>'.$i.'</td>';
				  		echo '<td>'.$preview.'</td>';
				  		echo '<td>files/'.$file.'</td>';
				  		echo'<td>
					    			<a  class="btn btn-danger" href = "del_file.php?name='.$file.'" >Удалить</a>
					    	</td>';
				  		echo '<tr>';
				  		$i++;
				  	}
				  ?>
				  </tbody>
			</table>
		</div>
	</main>
<?php

	require'template/footer.php';

?>
