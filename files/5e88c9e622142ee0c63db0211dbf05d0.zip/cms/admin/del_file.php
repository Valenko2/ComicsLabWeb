<?php
	session_start();
	require'../system/function.php';
	$errors = array();
	if(unlink('../files/'.$_GET['name'])){
		header('location: files.php');
	}else{
		$errors = 'файл не был удален';
		alerts('danger', $errors);
	}

