<?php 

$link = mysqli_connect('localhost', 'cj24332_valen', '69LrD38z', 'cj24332_valen');

    if(isset($_POST['go'])){
   $name = $_FILES['images']['name'];
   $tmp_name = $_FILES['images']['tmp_name'];



   $title = $_POST['title'];
   $content = $_POST['content']; 
   $url = $_POST['url'];

   

   $a= "INSERT INTO `page` (`id`, `url`, `title`, `content`, `activ`) VALUES (NULL, '$url', '$title', '$content', '1');";
   mysqli_query($link, $a);


}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>добавление страниц</title>

    <link href="reg.css" rel="stylesheet">

</head>
<body>
    <form method="POST" enctype="multipart/form-data">
        <p>  <input type="text" name="title" placeholder="введите название" class="input"></p>
        <p>  <input type="text" name="content" placeholder="введите контент" class="input"></p>
        <p>  <input type="text" name="url" placeholder="введите url" class="input"></p>
        <p><input type="submit" name="go" value="добавить" class="button"></p>
    </form>
</body>
</html>