<?php
    
    session_start();

    $link = mysqli_connect('localhost', 'cj24332_valen', '69LrD38z', 'cj24332_valen');
    
    

    $data = date('Y-m-d H:i:s');

    $q = 'INSERT INTO `comments` (`page_id`, `user_id`, `comment`, `data`)
    VALUES('.$_POST['page_id'].',"'.$_SESSION['user']['0'].'","'.$_POST['comment'].'","'.$data.'" )';
    mysqli_query($link, $q);

 
    header('location: page.php?url='.$_POST['page_url'].'');
   
?>