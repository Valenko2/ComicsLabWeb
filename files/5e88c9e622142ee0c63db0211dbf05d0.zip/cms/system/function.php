<?php
    function alerts($type, $array){
            foreach($array as $a){
                echo '<div class="mt-1 alert alert-'.$type.' alert-dismissible fade show" role="alert">
                '.$a.'
                 <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>';
             }
        }
    function vardump($a){
            echo'<pre>';
            var_dump($a);
            echo'</pre>';
    }
    function getFileExt($name){
        $nameArr = explode('.', $name);
        $ext = array_pop($nameArr);
        $ext = strtolower($ext);
        return $ext;
    }
    function generaterFIleName($name){
        $ext = getFileExt($name);
        $time = time();
        $newName = md5($time.$name). '.' . $ext;
        return $newName;
    }
?>