<div class="container mt3 mb-5">
    <form method="POST" action="add_comment.php">
        <textarea class="form-control" rows="3" name="comment"></textarea>
        <input type="hidden" name="page_url" value="<?php echo $url[0]['url']?>">
        <input type="hidden" name="page_id" value="<?php echo $url[0]['id']?>">
        <button type="submit" class="mt-3 btn btn-primary">Отправить</button>
    </form>
</div>