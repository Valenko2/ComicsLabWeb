
<?php


    require('link.php');
    $q = "SELECT * FROM `menu` ";
    $at = mysqli_query($link, $q);
    $menu = mysqli_fetch_all($at, MYSQLI_ASSOC);
    $a = "SELECT * FROM `page` WHERE `activ` = 1";
    $at = mysqli_query($link, $a);
    $page = mysqli_fetch_all($at, MYSQLI_ASSOC);
    
    

?>

<!DOCTYPE html>
<html lang="ru" class="h-100">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    pre{
      overflow: visible;
    }
  </style>
</head>
<body class="d-flex flex-column h-100">
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="/cms/index.php">GI</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
         <ul class="navbar-nav">                                     
              <?php

              if($_SESSION['user'] > 0){
                $q = 'SELECT * FROM `users` WHERE `login` = "'.$_SESSION["user"][0].'" ';
                $res = mysqli_query($link, $q);
                $user = mysqli_fetch_all($res, MYSQLI_ASSOC);
                if($user[0]['activ'] == 0){
                  echo '<li class="nav-item">';
                    echo '<a href="https://valen.xd0.ru/cms/exit.php" class="nav-link" aria-current="page">выйти </a>';
                  echo ' </li> ';
                }
                if($_SESSION['user'][0] == 'Admin'){
                  
                 echo '<a href="https://valen.xd0.ru/cms/admin/index.php" class="nav-link" aria-current="page">админка </a>';
                }
              }else{
                echo '<li class="nav-item">';
                  echo '<a href="https://valen.xd0.ru/cms/reg_form.php" class="nav-link" aria-current="page">регистрация</a>';
                echo '</li>';

                echo '<li class="nav-item">';
                  echo '<a href="https://valen.xd0.ru/cms/auth.php" class="nav-link" aria-current="page">войти</a>';
                echo '</li>';
              }
                  
              ?>
               
          <?php
              foreach($menu as $u){
                  echo '<li class="nav-item">
                           <a class="nav-link" href="'.$u['href'].'">'.$u['title'].'</a>
                        </li>';
              }
              ?>
          <li class="nav-item dropdown">  
            <a class="nav-link dropdown-toggle" href="#" id="dropdownXxl" data-bs-toggle="dropdown">сайты</a>
            <ul class="dropdown-menu" aria-labelledby="dropdownXxl">
              <?php
              foreach($page as $u){
                  echo '<li><a class="dropdown-item" href="page.php?url='.$u['url'].'">'.$u['title'].'</a></li>';
              }
              ?>
            </ul>
          </li>
           
        </ul>
      </div>
  </div>
</nav>