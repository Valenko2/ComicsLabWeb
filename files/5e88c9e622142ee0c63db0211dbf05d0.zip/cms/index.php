<?php
    session_start();

    require("template/header.php");
    require("link.php");


?>
  <!-- Begin page content -->
  <main class="flex-shrink-0">
    <div class="container">
      <h1 class="mt-5"></h1>
      <p class="lead"></p>
</div>
    </div>
  </main>

  <br>

 <?php

  if($_SESSION['user'] > 0){
      $q = 'SELECT * FROM `users` WHERE `login` = "'.$_SESSION["user"][0].'" ';
      $res = mysqli_query($link, $q);
      $user = mysqli_fetch_all($res, MYSQLI_ASSOC);
      if($user[0]['activ'] == 1){
        echo '<h1 style="color:red;">вы были забанены !!!</h1>';
      }else{
     
      echo '<div class="page-header">';
        echo '<h1 >привет,  '. $_SESSION['user'][0] . ' ! </h1>';
        echo '<small>спасибо что вы с нами</small>';
      }

    }else{
      echo 'зарегайся';
    }
  echo '</div>';
    require("template/footer.php");

  
  ?>

</body>
</html>
