<?php

function tre($a, $b, $c){
   
    if($a + $b > $c || $b + $c > $a || $a + $c > $b){
        echo 'true';
    }else{
        echo 'false';
    }
}

tre(1,1,1);


?>