<?php
     session_start();
     unset($_SESSION['user']);
     header('location: https://valen.xd0.ru/cms/index.php');
?>