<?php
    session_start();

    $link = mysqli_connect('localhost', 'cj24332_valen', '69LrD38z', 'cj24332_valen');

    $title = "Ошибка 404";
    $countent = "страница не найдена";
    require("template/header.php");
    if(empty($_GET['url']) == false){
        $q = "SELECT * FROM `page` WHERE url ='{$_GET['url']}'";
        $at = mysqli_query($link, $q);
        $url = mysqli_fetch_all($at, MYSQLI_ASSOC);
       
        
        if(count($url) == 0 || $url[0]['activ'] == 0){
          $title = "Ошибка 404";
          $countent = "страница не найдена";
        }else {
        $title = $url[0]['title'];
        $countent = $url[0]['content'];
        }
    }
   
   
?>
  <!-- Begin page content -->
  <main class="flex-shrink-0">
    <div class="container">
      <p class="mt-5"><?php echo $title ?></p>
      <p class="lead"><?php echo $countent ?></p>
    </div>
    <?php 
      if($url[0]['url'] != 'about' ){
        echo '<div class="container mt-5">';
         echo "<h3>Комментарии:</h3>";
        $q = "SELECT * FROM `comments` WHERE page_id = ".$url[0]['id']."";
        $at = mysqli_query($link, $q);
        foreach($at as $comment){
          echo '<hr boreder="1">';
          echo '<div class="container mt-3">';
          echo '<h3>'.$comment['user_id'].'<h3>';
          echo '<p>'.$comment['comment'].'</p>';
          echo '<br>';
          echo '<small>'.$comment['data'].'</small>';
          echo '</div>';
          if($_SESSION['user'][0] == 'Admin'){

            echo '<a href=admin/delet_comment.php?id='.$comment['id'].' class="btn btn-danger">удалить Комментарий</a>';
          };
          echo '<hr boreder="1">';
          

        }
        $q = 'SELECT * FROM `users` WHERE `login` = "'.$_SESSION["user"][0].'" ';
        $res = mysqli_query($link, $q);
        $user = mysqli_fetch_all($res, MYSQLI_ASSOC);

          echo '<br>';
        if($user[0]['activ'] == 0)
        {
          if($_SESSION['user'] > 0 )
          {
              require("template/commentFORM.php");
          }else{
              echo '<h2>что бы оставлять коментарии нужно войти на сайт</h2>';
          }
        }
      }

      echo '</div>';
    ?>
  </main>
  
    
 <?php
 require("template/footer.php");
 ?>
</body>
</html>