<?php

$link = mysqli_connect('localhost', 'cj24332_valen', '69LrD38z', 'cj24332_valen');

?>